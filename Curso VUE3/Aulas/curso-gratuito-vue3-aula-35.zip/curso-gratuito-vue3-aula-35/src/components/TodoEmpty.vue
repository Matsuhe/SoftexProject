<template>
    <div class="text-center text-lg text-gray-500">
        Você ainda não tem nenhuma tarefa.
    </div>
</template>

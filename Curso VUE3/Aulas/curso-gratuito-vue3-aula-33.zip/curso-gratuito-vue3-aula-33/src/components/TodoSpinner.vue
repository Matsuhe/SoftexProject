<template>
    <div class="text-center">
        <img
            src="@/assets/img/spinner.svg"
            alt=""
            class="inline-block w-5 h-5"
        >
    </div>
</template>

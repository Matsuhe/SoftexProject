<script>
export default {
    methods: {
        calculateDiscount() {
            // logica cabulosa
            console.log('calculateDiscount');
        },
        calculateTotalDiscount() {
            // logica cabulosa
            console.log('calculateTotalDiscount');
        },
    }
}
</script>

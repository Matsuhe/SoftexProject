# Curso gratuito Vue.js 3
Arquivos do curso gratuito Vue.js 3

[Link do curso](https://www.youtube.com/playlist?list=PLcoYAcR89n-qTYqfWTGxXMnAvCqY3JF8w)

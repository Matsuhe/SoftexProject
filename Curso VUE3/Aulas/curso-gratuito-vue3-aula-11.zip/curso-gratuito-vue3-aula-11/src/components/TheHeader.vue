<template>
    <header class="header">
        Header
    </header>
</template>

<script>
    export default {

    }
</script>

<style>
    .header {
        background: #000;
        color: #fff;
    }
</style>

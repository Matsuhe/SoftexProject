<template>
    <div class="card">
        Lorem ipsum dolor sit amet, consectetur adipisicing elit. Necessitatibus nesciunt optio quas quia quo saepe suscipit! A animi blanditiis, ea eum exercitationem id incidunt ipsa iste nam, qui repellat repellendus.
    </div>
</template>

<style scoped>
.card {
    background: bisque;
    padding: 10px;
    border-radius: 10px;
}
</style>
